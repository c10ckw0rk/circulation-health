<?php /* Template Name: home */
include 'baseTemplate.php';
