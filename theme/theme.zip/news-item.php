<?php /* Template Name: news-item */
include 'baseTemplate.php';
