<?php /* Template Name: news */
include 'baseTemplate.php';
