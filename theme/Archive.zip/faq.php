<?php /* Template Name: faq */
include 'baseTemplate.php';
